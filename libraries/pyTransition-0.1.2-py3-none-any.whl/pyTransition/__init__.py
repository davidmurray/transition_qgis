"""
pyTransition

A python package to interact with the Transition API.
"""

from .transition import Transition

__version__ = "0.1.0"
__author__ = "Transition City"
__credits__ = "Transition City"
